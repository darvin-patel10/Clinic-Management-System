import { Link } from "react-router-dom";
import Button from "@components/common/Button";
import { ROUTES } from "@utils/constants";

export function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[var(--color-surface-muted)] px-4 text-center">
      <p className="text-6xl font-bold text-[var(--color-primary-600)]">404</p>
      <h1 className="text-xl font-semibold text-[var(--color-text-primary)]">Page not found</h1>
      <p className="max-w-sm text-sm text-[var(--color-text-secondary)]">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <Link to={ROUTES.DASHBOARD}>
        <Button>Back to Dashboard</Button>
      </Link>
    </div>
  );
}

export default NotFound;
