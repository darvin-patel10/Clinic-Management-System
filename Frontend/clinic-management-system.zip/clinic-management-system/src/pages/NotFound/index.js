export { NotFound, default } from "./NotFound";
