import PagePlaceholder from "@components/common/PagePlaceholder";

export function Settings() {
  return <PagePlaceholder title="Settings" description="Application settings will be implemented here per Agent.md." />;
}

export default Settings;
