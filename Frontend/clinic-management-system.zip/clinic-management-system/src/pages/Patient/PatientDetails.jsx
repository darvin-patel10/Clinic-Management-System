import PagePlaceholder from "@components/common/PagePlaceholder";

export function PatientDetails() {
  return <PagePlaceholder title="Patient Details" description="Full patient profile and history will be implemented here per Agent.md." />;
}

export default PatientDetails;
