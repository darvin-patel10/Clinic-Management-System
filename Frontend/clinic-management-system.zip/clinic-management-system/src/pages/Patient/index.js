export { PatientList } from "./PatientList";
export { AddPatient } from "./AddPatient";
export { PatientDetails } from "./PatientDetails";
