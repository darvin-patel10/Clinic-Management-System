import PagePlaceholder from "@components/common/PagePlaceholder";

export function PatientList() {
  return <PagePlaceholder title="Patients" description="Patient list, search, and pagination will be implemented here per Agent.md." />;
}

export default PatientList;
