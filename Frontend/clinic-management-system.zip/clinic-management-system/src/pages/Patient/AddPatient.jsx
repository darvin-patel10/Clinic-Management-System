import PagePlaceholder from "@components/common/PagePlaceholder";

export function AddPatient() {
  return <PagePlaceholder title="Add Patient" description="The Add Patient form will be implemented here per Agent.md." />;
}

export default AddPatient;
