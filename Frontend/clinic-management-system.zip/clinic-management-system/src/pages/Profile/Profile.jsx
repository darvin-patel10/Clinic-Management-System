import PagePlaceholder from "@components/common/PagePlaceholder";

export function Profile() {
  return <PagePlaceholder title="Profile" description="Doctor profile management will be implemented here per Agent.md." />;
}

export default Profile;
