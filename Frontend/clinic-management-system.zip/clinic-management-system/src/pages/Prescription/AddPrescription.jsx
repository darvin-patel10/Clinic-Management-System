import PagePlaceholder from "@components/common/PagePlaceholder";

export function AddPrescription() {
  return <PagePlaceholder title="Add Prescription" description="Multi-medicine prescription authoring will be implemented here per Agent.md." />;
}

export default AddPrescription;
