import PagePlaceholder from "@components/common/PagePlaceholder";

export function History() {
  return <PagePlaceholder title="Prescription History" description="Prescription history will be implemented here per Agent.md." />;
}

export default History;
