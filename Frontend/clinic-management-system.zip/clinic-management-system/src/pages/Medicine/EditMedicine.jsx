import PagePlaceholder from "@components/common/PagePlaceholder";

export function EditMedicine() {
  return <PagePlaceholder title="Edit Medicine" description="The Edit Medicine form will be implemented here per Agent.md." />;
}

export default EditMedicine;
