import PagePlaceholder from "@components/common/PagePlaceholder";

export function MedicineList() {
  return <PagePlaceholder title="Medicines" description="Medicine list, search, filtering, and pagination will be implemented here per Agent.md." />;
}

export default MedicineList;
