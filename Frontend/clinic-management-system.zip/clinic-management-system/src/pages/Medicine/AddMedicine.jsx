import PagePlaceholder from "@components/common/PagePlaceholder";

export function AddMedicine() {
  return <PagePlaceholder title="Add Medicine" description="The Add Medicine form will be implemented here per Agent.md." />;
}

export default AddMedicine;
