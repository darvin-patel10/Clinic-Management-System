import PagePlaceholder from "@components/common/PagePlaceholder";

export function Dashboard() {
  return <PagePlaceholder title="Dashboard" description="Statistics, charts, and recent activity will be implemented here per Agent.md." />;
}

export default Dashboard;
