// Prescription feature service layer.
// Scaffolding only — CRUD + history methods to be implemented alongside
// the Prescriptions feature build-out. Keep the same shape as
// auth.service.js.

export const prescriptionService = {
  // getPrescriptions, getPrescriptionById, createPrescription, getHistory
};

export default prescriptionService;
