import axiosInstance from "@api/axios";
import { ENDPOINTS } from "@api/endpoints";

// Service layer: the ONLY place that calls axios for this feature.
// Components/hooks call these functions, never axios directly.

export async function login({ email, password }) {
  const { data } = await axiosInstance.post(ENDPOINTS.AUTH.LOGIN, {
    email,
    password,
  });
  return data;
}

export async function logout() {
  const { data } = await axiosInstance.post(ENDPOINTS.AUTH.LOGOUT);
  return data;
}

export async function refreshToken(refreshTokenValue) {
  const { data } = await axiosInstance.post(ENDPOINTS.AUTH.REFRESH_TOKEN, {
    refreshToken: refreshTokenValue,
  });
  return data;
}

export async function getCurrentUser() {
  const { data } = await axiosInstance.get(ENDPOINTS.AUTH.ME);
  return data;
}

export const authService = { login, logout, refreshToken, getCurrentUser };
export default authService;
