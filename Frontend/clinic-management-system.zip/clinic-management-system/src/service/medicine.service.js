// Medicine feature service layer.
// Scaffolding only — CRUD methods to be implemented alongside the
// Medicines feature build-out. Keep the same shape as auth.service.js:
// axiosInstance + ENDPOINTS.MEDICINES, one exported async fn per call.
//
// import axiosInstance from "@api/axios";
// import { ENDPOINTS } from "@api/endpoints";

export const medicineService = {
  // getMedicines, getMedicineById, createMedicine, updateMedicine, deleteMedicine
};

export default medicineService;
