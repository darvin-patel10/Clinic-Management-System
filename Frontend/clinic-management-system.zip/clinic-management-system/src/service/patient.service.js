// Patient feature service layer.
// Scaffolding only — CRUD methods to be implemented alongside the
// Patients feature build-out. Keep the same shape as auth.service.js.

export const patientService = {
  // getPatients, getPatientById, createPatient, updatePatient, deletePatient
};

export default patientService;
