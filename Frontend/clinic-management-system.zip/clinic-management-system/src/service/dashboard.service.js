// Dashboard feature service layer.
// Scaffolding only — read-only aggregate endpoints to be implemented
// alongside the Dashboard feature build-out. Keep the same shape as
// auth.service.js.

export const dashboardService = {
  // getStats, getRevenue, getRecentPatients, getRecentPrescriptions, getLowStockMedicines
};

export default dashboardService;
