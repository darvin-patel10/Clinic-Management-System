import { useCallback, useMemo, useState } from "react";
import { PAGINATION_DEFAULTS } from "@utils/constants";

/**
 * Local pagination-state controller. Pairs with server-driven lists:
 * expose `page`/`limit` to a React Query key, and feed `totalItems`
 * back in once the response arrives.
 */
export function usePagination({
  initialPage = PAGINATION_DEFAULTS.PAGE,
  initialLimit = PAGINATION_DEFAULTS.LIMIT,
} = {}) {
  const [page, setPage] = useState(initialPage);
  const [limit, setLimit] = useState(initialLimit);
  const [totalItems, setTotalItems] = useState(0);

  const totalPages = useMemo(
    () => Math.max(1, Math.ceil(totalItems / limit)),
    [totalItems, limit]
  );

  const nextPage = useCallback(
    () => setPage((current) => Math.min(current + 1, totalPages)),
    [totalPages]
  );

  const prevPage = useCallback(() => setPage((current) => Math.max(current - 1, 1)), []);

  const goToPage = useCallback(
    (targetPage) => setPage(Math.min(Math.max(targetPage, 1), totalPages)),
    [totalPages]
  );

  return {
    page,
    limit,
    totalItems,
    totalPages,
    setLimit,
    setTotalItems,
    nextPage,
    prevPage,
    goToPage,
  };
}

export default usePagination;
