import { useCallback, useState } from "react";

/**
 * Minimal open/close controller for the Modal / ConfirmDialog
 * components. Keeps modal visibility state out of feature components.
 */
export function useModal(initialOpen = false) {
  const [isOpen, setIsOpen] = useState(initialOpen);

  const open = useCallback(() => setIsOpen(true), []);
  const close = useCallback(() => setIsOpen(false), []);
  const toggle = useCallback(() => setIsOpen((current) => !current), []);

  return { isOpen, open, close, toggle };
}

export default useModal;
