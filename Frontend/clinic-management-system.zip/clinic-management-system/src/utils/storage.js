// Thin wrapper around localStorage so the rest of the app never touches
// window.localStorage directly. Makes it trivial to swap storage strategy
// (e.g. httpOnly cookies) later without touching call sites.

export const storage = {
  get(key) {
    try {
      const value = window.localStorage.getItem(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      console.error(`storage.get failed for key "${key}"`, error);
      return null;
    }
  },

  set(key, value) {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error(`storage.set failed for key "${key}"`, error);
    }
  },

  remove(key) {
    try {
      window.localStorage.removeItem(key);
    } catch (error) {
      console.error(`storage.remove failed for key "${key}"`, error);
    }
  },

  clear() {
    try {
      window.localStorage.clear();
    } catch (error) {
      console.error("storage.clear failed", error);
    }
  },
};
