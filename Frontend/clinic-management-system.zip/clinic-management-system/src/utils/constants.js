// Central place for magic strings/numbers used across the app.
// Never hardcode these values inline in components/services.

export const APP_NAME = "Clinic Management System";

export const STORAGE_KEYS = {
  ACCESS_TOKEN: "cms_access_token",
  REFRESH_TOKEN: "cms_refresh_token",
  USER: "cms_user",
};

export const ROUTES = {
  LOGIN: "/login",
  DASHBOARD: "/dashboard",
  MEDICINES: "/medicines",
  MEDICINES_ADD: "/medicines/add",
  MEDICINES_EDIT: "/medicines/:id/edit",
  PATIENTS: "/patients",
  PATIENTS_ADD: "/patients/add",
  PATIENTS_DETAILS: "/patients/:id",
  PRESCRIPTIONS: "/prescriptions",
  PRESCRIPTIONS_ADD: "/prescriptions/add",
  PRESCRIPTIONS_HISTORY: "/prescriptions/history",
  SETTINGS: "/settings",
  PROFILE: "/profile",
  NOT_FOUND: "*",
};

export const QUERY_KEYS = {
  AUTH_USER: "auth-user",
  DASHBOARD_STATS: "dashboard-stats",
  MEDICINES: "medicines",
  MEDICINE_DETAILS: "medicine-details",
  PATIENTS: "patients",
  PATIENT_DETAILS: "patient-details",
  PRESCRIPTIONS: "prescriptions",
  PRESCRIPTION_DETAILS: "prescription-details",
};

export const PAGINATION_DEFAULTS = {
  PAGE: 1,
  LIMIT: 10,
};

export const HTTP_STATUS = {
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  SERVER_ERROR: 500,
};

// Auto logout after this many ms of inactivity (30 minutes).
export const AUTO_LOGOUT_MS = 30 * 60 * 1000;
