// Presentation-layer formatting helpers. Keep raw data transformation
// (parsing/normalizing API responses) in the service layer, not here.

export function formatDate(date, options = { day: "2-digit", month: "short", year: "numeric" }) {
  if (!date) return "—";
  try {
    return new Intl.DateTimeFormat("en-US", options).format(new Date(date));
  } catch {
    return "—";
  }
}

export function formatDateTime(date) {
  return formatDate(date, {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatCurrency(amount, currency = "INR") {
  if (amount == null || Number.isNaN(Number(amount))) return "—";
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(Number(amount));
}

export function formatNumber(value) {
  if (value == null || Number.isNaN(Number(value))) return "—";
  return new Intl.NumberFormat("en-IN").format(Number(value));
}
