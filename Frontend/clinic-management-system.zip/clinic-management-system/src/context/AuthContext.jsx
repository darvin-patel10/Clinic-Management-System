import { createContext, useCallback, useEffect, useMemo, useState } from "react";
import toast from "react-hot-toast";
import authService from "@service/auth.service";
import { AUTO_LOGOUT_MS, STORAGE_KEYS } from "@utils/constants";
import { storage } from "@utils/storage";

export const AuthContext = createContext(undefined);

let inactivityTimer;

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => storage.get(STORAGE_KEYS.USER));
  const [isInitializing, setIsInitializing] = useState(true);

  const isAuthenticated = Boolean(user);

  const clearSession = useCallback(() => {
    storage.remove(STORAGE_KEYS.ACCESS_TOKEN);
    storage.remove(STORAGE_KEYS.REFRESH_TOKEN);
    storage.remove(STORAGE_KEYS.USER);
    setUser(null);
  }, []);

  const login = useCallback(async (credentials) => {
    const data = await authService.login(credentials);
    storage.set(STORAGE_KEYS.ACCESS_TOKEN, data.accessToken);
    storage.set(STORAGE_KEYS.REFRESH_TOKEN, data.refreshToken);
    storage.set(STORAGE_KEYS.USER, data.user);
    setUser(data.user);
    return data.user;
  }, []);

  const logout = useCallback(
    async ({ silent = false } = {}) => {
      try {
        if (!silent) await authService.logout();
      } catch (error) {
        console.error("Logout request failed", error);
      } finally {
        clearSession();
      }
    },
    [clearSession]
  );

  // Bootstrap session from persisted token on first load.
  useEffect(() => {
    const token = storage.get(STORAGE_KEYS.ACCESS_TOKEN);
    if (!token) {
      setIsInitializing(false);
      return;
    }
    // A stored user is trusted for initial paint; a real app should
    // still validate the token against authService.getCurrentUser()
    // once the /auth/me endpoint is available.
    setIsInitializing(false);
  }, []);

  // Listen for forced logout dispatched by the axios interceptor when
  // refresh-token exchange fails.
  useEffect(() => {
    function handleSessionExpired() {
      clearSession();
      toast.error("Your session has expired. Please log in again.");
    }
    window.addEventListener("auth:session-expired", handleSessionExpired);
    return () => window.removeEventListener("auth:session-expired", handleSessionExpired);
  }, [clearSession]);

  // Auto logout after a period of inactivity — required for a
  // doctor-facing clinical app handling patient data.
  useEffect(() => {
    if (!isAuthenticated) return undefined;

    function resetTimer() {
      clearTimeout(inactivityTimer);
      inactivityTimer = setTimeout(() => {
        logout({ silent: true });
        toast("You were logged out due to inactivity.", { icon: "🕒" });
      }, AUTO_LOGOUT_MS);
    }

    const activityEvents = ["mousemove", "keydown", "click", "scroll"];
    activityEvents.forEach((event) => window.addEventListener(event, resetTimer));
    resetTimer();

    return () => {
      clearTimeout(inactivityTimer);
      activityEvents.forEach((event) => window.removeEventListener(event, resetTimer));
    };
  }, [isAuthenticated, logout]);

  const value = useMemo(
    () => ({ user, isAuthenticated, isInitializing, login, logout }),
    [user, isAuthenticated, isInitializing, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
