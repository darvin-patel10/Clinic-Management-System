import { Link, useLocation } from "react-router-dom";
import { HiChevronRight } from "react-icons/hi";

function toLabel(segment) {
  return segment
    .replace(/-/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

export function Breadcrumb() {
  const { pathname } = useLocation();
  const segments = pathname.split("/").filter(Boolean);

  if (segments.length === 0) return null;

  return (
    <nav aria-label="Breadcrumb" className="mb-4">
      <ol className="flex items-center gap-1.5 text-sm text-[var(--color-text-secondary)]">
        <li>
          <Link to="/dashboard" className="hover:text-[var(--color-primary-600)]">
            Home
          </Link>
        </li>
        {segments.map((segment, index) => {
          const path = `/${segments.slice(0, index + 1).join("/")}`;
          const isLast = index === segments.length - 1;
          return (
            <li key={path} className="flex items-center gap-1.5">
              <HiChevronRight className="h-3.5 w-3.5 text-[var(--color-text-muted)]" aria-hidden="true" />
              {isLast ? (
                <span aria-current="page" className="font-medium text-[var(--color-text-primary)]">
                  {toLabel(segment)}
                </span>
              ) : (
                <Link to={path} className="hover:text-[var(--color-primary-600)]">
                  {toLabel(segment)}
                </Link>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

export default Breadcrumb;
