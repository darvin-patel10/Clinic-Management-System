import { HiOutlineMenu, HiOutlineLogout } from "react-icons/hi";
import { useAuth } from "@hooks/useAuth";
import Avatar from "@components/common/Avatar";

export function Navbar({ onToggleSidebar }) {
  const { user, logout } = useAuth();

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-[var(--color-border)] bg-white/80 px-4 backdrop-blur sm:px-6">
      <button
        type="button"
        onClick={onToggleSidebar}
        className="rounded-md p-2 text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-alt)] lg:hidden"
        aria-label="Toggle navigation menu"
      >
        <HiOutlineMenu className="h-6 w-6" />
      </button>

      <div className="hidden lg:block" />

      <div className="flex items-center gap-4">
        <div className="hidden text-right sm:block">
          <p className="text-sm font-medium text-[var(--color-text-primary)]">
            {user?.name ?? "Doctor"}
          </p>
          <p className="text-xs text-[var(--color-text-muted)]">{user?.role ?? "Practitioner"}</p>
        </div>
        <Avatar name={user?.name} src={user?.avatarUrl} size="sm" />
        <button
          type="button"
          onClick={() => logout()}
          className="rounded-md p-2 text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-alt)]"
          aria-label="Log out"
          title="Log out"
        >
          <HiOutlineLogout className="h-5 w-5" />
        </button>
      </div>
    </header>
  );
}

export default Navbar;
