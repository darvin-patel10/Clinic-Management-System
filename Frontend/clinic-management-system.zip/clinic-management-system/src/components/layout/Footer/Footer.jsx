export function Footer() {
  return (
    <footer className="border-t border-[var(--color-border)] px-6 py-4 text-center text-xs text-[var(--color-text-muted)]">
      © {new Date().getFullYear()} Clinic Management System. For registered practitioners only.
    </footer>
  );
}

export default Footer;
