import { NavLink } from "react-router-dom";
import {
  HiOutlineViewGrid,
  HiOutlineBeaker,
  HiOutlineUserGroup,
  HiOutlineClipboardList,
  HiOutlineCog,
  HiOutlineUserCircle,
} from "react-icons/hi";
import { ROUTES } from "@utils/constants";
import { cn } from "@utils/helpers";

const NAV_ITEMS = [
  { label: "Dashboard", to: ROUTES.DASHBOARD, icon: HiOutlineViewGrid },
  { label: "Medicines", to: ROUTES.MEDICINES, icon: HiOutlineBeaker },
  { label: "Patients", to: ROUTES.PATIENTS, icon: HiOutlineUserGroup },
  { label: "Prescriptions", to: ROUTES.PRESCRIPTIONS, icon: HiOutlineClipboardList },
  { label: "Profile", to: ROUTES.PROFILE, icon: HiOutlineUserCircle },
  { label: "Settings", to: ROUTES.SETTINGS, icon: HiOutlineCog },
];

export function Sidebar({ isOpen = true }) {
  return (
    <aside
      className={cn(
        "fixed inset-y-0 left-0 z-30 flex w-64 flex-col border-r border-[var(--color-border)] bg-white transition-transform duration-200 lg:static lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}
      aria-label="Main navigation"
    >
      <div className="flex h-16 items-center gap-2 border-b border-[var(--color-border)] px-6">
        <div className="h-8 w-8 rounded-lg bg-[var(--color-primary-600)]" aria-hidden="true" />
        <span className="text-base font-semibold text-[var(--color-text-primary)]">Clinic CMS</span>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4 scrollbar-thin">
        {NAV_ITEMS.map(({ label, to, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 rounded-[var(--radius-control)] px-3 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-[var(--color-primary-50)] text-[var(--color-primary-700)]"
                  : "text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-alt)]"
              )
            }
          >
            <Icon className="h-5 w-5 shrink-0" aria-hidden="true" />
            {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}

export default Sidebar;
