import { cn } from "@utils/helpers";

export function Card({ children, className = "", padded = true, as: Tag = "div", ...rest }) {
  return (
    <Tag className={cn("card-surface", padded && "p-6", className)} {...rest}>
      {children}
    </Tag>
  );
}

export default Card;
