import { forwardRef, useId } from "react";
import { cn } from "@utils/helpers";

export const TextArea = forwardRef(function TextArea(
  { label, error, hint, rows = 4, className = "", id, required = false, ...rest },
  ref
) {
  const generatedId = useId();
  const textareaId = id || generatedId;

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={textareaId} className="text-sm font-medium text-[var(--color-text-primary)]">
          {label}
          {required && <span className="text-[var(--color-danger)]"> *</span>}
        </label>
      )}
      <textarea
        ref={ref}
        id={textareaId}
        rows={rows}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${textareaId}-error` : hint ? `${textareaId}-hint` : undefined}
        className={cn(
          "resize-y rounded-[var(--radius-control)] border bg-white px-3 py-2 text-sm text-[var(--color-text-primary)]",
          "placeholder:text-[var(--color-text-muted)] transition-colors",
          "border-[var(--color-border)] focus:border-[var(--color-primary-500)]",
          error && "border-[var(--color-danger)] focus:border-[var(--color-danger)]",
          className
        )}
        {...rest}
      />
      {error ? (
        <p id={`${textareaId}-error`} className="text-xs text-[var(--color-danger)]">
          {error}
        </p>
      ) : hint ? (
        <p id={`${textareaId}-hint`} className="text-xs text-[var(--color-text-muted)]">
          {hint}
        </p>
      ) : null}
    </div>
  );
});

export default TextArea;
