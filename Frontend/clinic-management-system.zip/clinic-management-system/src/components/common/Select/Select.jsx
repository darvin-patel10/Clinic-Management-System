import { forwardRef, useId } from "react";
import { cn } from "@utils/helpers";

export const Select = forwardRef(function Select(
  { label, error, hint, options = [], placeholder = "Select an option", className = "", id, required = false, ...rest },
  ref
) {
  const generatedId = useId();
  const selectId = id || generatedId;

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={selectId} className="text-sm font-medium text-[var(--color-text-primary)]">
          {label}
          {required && <span className="text-[var(--color-danger)]"> *</span>}
        </label>
      )}
      <select
        ref={ref}
        id={selectId}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${selectId}-error` : hint ? `${selectId}-hint` : undefined}
        className={cn(
          "h-10 rounded-[var(--radius-control)] border bg-white px-3 text-sm text-[var(--color-text-primary)]",
          "border-[var(--color-border)] focus:border-[var(--color-primary-500)]",
          error && "border-[var(--color-danger)] focus:border-[var(--color-danger)]",
          className
        )}
        {...rest}
      >
        <option value="" disabled>
          {placeholder}
        </option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error ? (
        <p id={`${selectId}-error`} className="text-xs text-[var(--color-danger)]">
          {error}
        </p>
      ) : hint ? (
        <p id={`${selectId}-hint`} className="text-xs text-[var(--color-text-muted)]">
          {hint}
        </p>
      ) : null}
    </div>
  );
});

export default Select;
