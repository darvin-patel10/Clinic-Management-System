import { forwardRef, useId } from "react";
import { cn } from "@utils/helpers";

export const Input = forwardRef(function Input(
  { label, error, hint, className = "", id, required = false, ...rest },
  ref
) {
  const generatedId = useId();
  const inputId = id || generatedId;

  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label htmlFor={inputId} className="text-sm font-medium text-[var(--color-text-primary)]">
          {label}
          {required && <span className="text-[var(--color-danger)]"> *</span>}
        </label>
      )}
      <input
        ref={ref}
        id={inputId}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined}
        className={cn(
          "h-10 rounded-[var(--radius-control)] border bg-white px-3 text-sm text-[var(--color-text-primary)]",
          "placeholder:text-[var(--color-text-muted)] transition-colors",
          "border-[var(--color-border)] focus:border-[var(--color-primary-500)]",
          error && "border-[var(--color-danger)] focus:border-[var(--color-danger)]",
          className
        )}
        {...rest}
      />
      {error ? (
        <p id={`${inputId}-error`} className="text-xs text-[var(--color-danger)]">
          {error}
        </p>
      ) : hint ? (
        <p id={`${inputId}-hint`} className="text-xs text-[var(--color-text-muted)]">
          {hint}
        </p>
      ) : null}
    </div>
  );
});

export default Input;
