import { Component } from "react";
import Button from "@components/common/Button";

export class ErrorBoundary extends Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    // Wire this up to an error-reporting service (Sentry, etc.) later.
    console.error("Uncaught application error:", error, errorInfo);
  }

  handleReload = () => {
    this.setState({ hasError: false });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[var(--color-surface-muted)] px-4 text-center">
          <h1 className="text-xl font-semibold text-[var(--color-text-primary)]">
            Something went wrong
          </h1>
          <p className="max-w-sm text-sm text-[var(--color-text-secondary)]">
            An unexpected error occurred. Reloading the page usually fixes this.
          </p>
          <Button onClick={this.handleReload}>Reload page</Button>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
