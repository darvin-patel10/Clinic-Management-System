import Loader from "@components/common/Loader";
import EmptyState from "@components/common/EmptyState";
import ErrorState from "@components/common/ErrorState";

/**
 * Generic, presentational data table.
 *
 * columns: [{ key, header, render?(row) }]
 * data: array of row objects
 */
export function Table({ columns, data = [], isLoading = false, isError = false, onRetry, emptyMessage }) {
  if (isLoading) {
    return (
      <div className="py-12">
        <Loader label="Loading data…" />
      </div>
    );
  }

  if (isError) {
    return <ErrorState onRetry={onRetry} />;
  }

  if (!data.length) {
    return <EmptyState title={emptyMessage || "No records found"} />;
  }

  return (
    <div className="scrollbar-thin overflow-x-auto rounded-[var(--radius-card)] border border-[var(--color-border)]">
      <table className="w-full min-w-[640px] text-left text-sm">
        <thead className="bg-[var(--color-surface-alt)] text-xs uppercase tracking-wide text-[var(--color-text-secondary)]">
          <tr>
            {columns.map((column) => (
              <th key={column.key} scope="col" className="px-4 py-3 font-semibold">
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-[var(--color-border)] bg-white">
          {data.map((row, rowIndex) => (
            <tr key={row.id ?? rowIndex} className="hover:bg-[var(--color-surface-muted)]">
              {columns.map((column) => (
                <td key={column.key} className="px-4 py-3 text-[var(--color-text-primary)]">
                  {column.render ? column.render(row) : row[column.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Table;
