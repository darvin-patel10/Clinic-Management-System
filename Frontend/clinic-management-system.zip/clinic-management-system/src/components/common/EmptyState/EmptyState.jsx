import { HiOutlineInbox } from "react-icons/hi";

export function EmptyState({
  icon: Icon = HiOutlineInbox,
  title = "Nothing here yet",
  description,
  action,
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
      <Icon className="h-10 w-10 text-[var(--color-text-muted)]" aria-hidden="true" />
      <h3 className="text-sm font-semibold text-[var(--color-text-primary)]">{title}</h3>
      {description && <p className="max-w-sm text-sm text-[var(--color-text-secondary)]">{description}</p>}
      {action}
    </div>
  );
}

export default EmptyState;
