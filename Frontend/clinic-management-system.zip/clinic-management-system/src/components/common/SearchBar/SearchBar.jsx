import { useEffect, useState } from "react";
import { HiOutlineSearch } from "react-icons/hi";
import { useDebounce } from "@hooks/useDebounce";
import { cn } from "@utils/helpers";

export function SearchBar({ placeholder = "Search…", onSearch, delay = 400, className = "" }) {
  const [value, setValue] = useState("");
  const debouncedValue = useDebounce(value, delay);

  useEffect(() => {
    onSearch?.(debouncedValue.trim());
  }, [debouncedValue, onSearch]);

  return (
    <div className={cn("relative", className)}>
      <HiOutlineSearch className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-text-muted)]" />
      <input
        type="search"
        value={value}
        onChange={(event) => setValue(event.target.value)}
        placeholder={placeholder}
        aria-label={placeholder}
        className="h-10 w-full rounded-[var(--radius-control)] border border-[var(--color-border)] bg-white pl-9 pr-3 text-sm text-[var(--color-text-primary)] placeholder:text-[var(--color-text-muted)] focus:border-[var(--color-primary-500)]"
      />
    </div>
  );
}

export default SearchBar;
