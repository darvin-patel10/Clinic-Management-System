import { HiChevronLeft, HiChevronRight } from "react-icons/hi";
import { cn } from "@utils/helpers";

export function Pagination({ page, totalPages, onPrev, onNext, onGoTo }) {
  if (totalPages <= 1) return null;

  const pages = Array.from({ length: totalPages }, (_, index) => index + 1);

  return (
    <nav className="flex items-center justify-between gap-4" aria-label="Pagination">
      <button
        type="button"
        onClick={onPrev}
        disabled={page === 1}
        className="inline-flex h-9 w-9 items-center justify-center rounded-[var(--radius-control)] border border-[var(--color-border)] text-[var(--color-text-secondary)] disabled:opacity-40"
        aria-label="Previous page"
      >
        <HiChevronLeft className="h-4 w-4" />
      </button>

      <ul className="flex items-center gap-1">
        {pages.map((pageNumber) => (
          <li key={pageNumber}>
            <button
              type="button"
              onClick={() => onGoTo?.(pageNumber)}
              aria-current={pageNumber === page ? "page" : undefined}
              className={cn(
                "flex h-9 min-w-9 items-center justify-center rounded-[var(--radius-control)] px-2 text-sm font-medium",
                pageNumber === page
                  ? "bg-[var(--color-primary-600)] text-white"
                  : "text-[var(--color-text-secondary)] hover:bg-[var(--color-surface-alt)]"
              )}
            >
              {pageNumber}
            </button>
          </li>
        ))}
      </ul>

      <button
        type="button"
        onClick={onNext}
        disabled={page === totalPages}
        className="inline-flex h-9 w-9 items-center justify-center rounded-[var(--radius-control)] border border-[var(--color-border)] text-[var(--color-text-secondary)] disabled:opacity-40"
        aria-label="Next page"
      >
        <HiChevronRight className="h-4 w-4" />
      </button>
    </nav>
  );
}

export default Pagination;
