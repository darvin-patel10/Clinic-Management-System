import { cn } from "@utils/helpers";

const SIZE_MAP = { sm: "h-5 w-5 border-2", md: "h-8 w-8 border-2", lg: "h-12 w-12 border-[3px]" };

export function Loader({ size = "md", fullScreen = false, label = "Loading…", className = "" }) {
  const spinner = (
    <div className="flex flex-col items-center justify-center gap-3" role="status" aria-live="polite">
      <span
        className={cn(
          "animate-spin rounded-full border-[var(--color-primary-200)] border-t-[var(--color-primary-600)]",
          SIZE_MAP[size],
          className
        )}
      />
      <span className="text-sm text-[var(--color-text-secondary)]">{label}</span>
    </div>
  );

  if (fullScreen) {
    return <div className="flex min-h-[60vh] w-full items-center justify-center">{spinner}</div>;
  }

  return spinner;
}

export default Loader;
