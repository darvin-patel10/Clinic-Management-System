import Card from "@components/common/Card";

/**
 * Temporary placeholder used by pages whose business logic has not been
 * built yet. Once a feature is implemented, delete the placeholder call
 * and replace it with real UI — do not leave this in production code.
 */
export function PagePlaceholder({ title, description }) {
  return (
    <Card className="flex flex-col items-center justify-center gap-2 py-20 text-center">
      <h1 className="text-lg font-semibold text-[var(--color-text-primary)]">{title}</h1>
      <p className="max-w-md text-sm text-[var(--color-text-secondary)]">
        {description || "This module is scaffolded and ready for feature implementation per Agent.md."}
      </p>
    </Card>
  );
}

export default PagePlaceholder;
