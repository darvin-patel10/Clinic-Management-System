import { getInitials, cn } from "@utils/helpers";

const SIZE_CLASSES = { sm: "h-8 w-8 text-xs", md: "h-10 w-10 text-sm", lg: "h-14 w-14 text-base" };

export function Avatar({ name = "", src, size = "md", className = "" }) {
  if (src) {
    return (
      <img
        src={src}
        alt={name || "Avatar"}
        className={cn("rounded-full object-cover", SIZE_CLASSES[size], className)}
      />
    );
  }

  return (
    <div
      className={cn(
        "flex items-center justify-center rounded-full bg-[var(--color-primary-100)] font-semibold text-[var(--color-primary-700)]",
        SIZE_CLASSES[size],
        className
      )}
      aria-hidden="true"
    >
      {getInitials(name) || "?"}
    </div>
  );
}

export default Avatar;
