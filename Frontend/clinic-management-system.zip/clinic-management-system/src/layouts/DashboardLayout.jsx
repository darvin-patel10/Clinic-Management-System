import { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "@components/layout/Sidebar";
import Navbar from "@components/layout/Navbar";
import Footer from "@components/layout/Footer";
import Breadcrumb from "@components/layout/Breadcrumb";

export function DashboardLayout() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-[var(--color-surface-muted)]">
      <Sidebar isOpen={isSidebarOpen} />

      {isSidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-slate-900/30 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      <div className="flex min-h-screen flex-1 flex-col lg:pl-0">
        <Navbar onToggleSidebar={() => setIsSidebarOpen((open) => !open)} />
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <Breadcrumb />
          <Outlet />
        </main>
        <Footer />
      </div>
    </div>
  );
}

export default DashboardLayout;
