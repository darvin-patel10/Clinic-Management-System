import { Outlet } from "react-router-dom";

export function AuthLayout() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[var(--color-surface-muted)] px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center gap-2">
          <div className="h-12 w-12 rounded-xl bg-[var(--color-primary-600)]" aria-hidden="true" />
          <h1 className="text-lg font-semibold text-[var(--color-text-primary)]">
            Clinic Management System
          </h1>
          <p className="text-sm text-[var(--color-text-secondary)]">Sign in to continue</p>
        </div>
        <div className="card-surface p-8">
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default AuthLayout;
