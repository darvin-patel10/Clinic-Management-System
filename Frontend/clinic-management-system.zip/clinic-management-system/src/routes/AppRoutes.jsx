import { lazy, Suspense } from "react";
import { Routes, Route } from "react-router-dom";
import ProtectedRoute from "@routes/ProtectedRoute";
import PublicRoute from "@routes/PublicRoute";
import AuthLayout from "@layouts/AuthLayout";
import DashboardLayout from "@layouts/DashboardLayout";
import Loader from "@components/common/Loader";

// Every page is lazy-loaded so each route ships its own JS chunk.
const Login = lazy(() => import("@pages/Auth/Login"));
const Dashboard = lazy(() => import("@pages/Dashboard/Dashboard"));
const MedicineList = lazy(() => import("@pages/Medicine/MedicineList"));
const AddMedicine = lazy(() => import("@pages/Medicine/AddMedicine"));
const EditMedicine = lazy(() => import("@pages/Medicine/EditMedicine"));
const PatientList = lazy(() => import("@pages/Patient/PatientList"));
const AddPatient = lazy(() => import("@pages/Patient/AddPatient"));
const PatientDetails = lazy(() => import("@pages/Patient/PatientDetails"));
const AddPrescription = lazy(() => import("@pages/Prescription/AddPrescription"));
const PrescriptionHistory = lazy(() => import("@pages/Prescription/History"));
const Settings = lazy(() => import("@pages/Settings/Settings"));
const Profile = lazy(() => import("@pages/Profile/Profile"));
const NotFound = lazy(() => import("@pages/NotFound/NotFound"));

function PageSuspense({ children }) {
  return <Suspense fallback={<Loader fullScreen label="Loading page…" />}>{children}</Suspense>;
}

export function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route element={<PublicRoute />}>
        <Route element={<AuthLayout />}>
          <Route
            path="/login"
            element={
              <PageSuspense>
                <Login />
              </PageSuspense>
            }
          />
        </Route>
      </Route>

      {/* Protected routes */}
      <Route element={<ProtectedRoute />}>
        <Route element={<DashboardLayout />}>
          <Route
            index
            element={
              <PageSuspense>
                <Dashboard />
              </PageSuspense>
            }
          />
          <Route
            path="dashboard"
            element={
              <PageSuspense>
                <Dashboard />
              </PageSuspense>
            }
          />

          <Route
            path="medicines"
            element={
              <PageSuspense>
                <MedicineList />
              </PageSuspense>
            }
          />
          <Route
            path="medicines/add"
            element={
              <PageSuspense>
                <AddMedicine />
              </PageSuspense>
            }
          />
          <Route
            path="medicines/:id/edit"
            element={
              <PageSuspense>
                <EditMedicine />
              </PageSuspense>
            }
          />

          <Route
            path="patients"
            element={
              <PageSuspense>
                <PatientList />
              </PageSuspense>
            }
          />
          <Route
            path="patients/add"
            element={
              <PageSuspense>
                <AddPatient />
              </PageSuspense>
            }
          />
          <Route
            path="patients/:id"
            element={
              <PageSuspense>
                <PatientDetails />
              </PageSuspense>
            }
          />

          <Route
            path="prescriptions/add"
            element={
              <PageSuspense>
                <AddPrescription />
              </PageSuspense>
            }
          />
          <Route
            path="prescriptions/history"
            element={
              <PageSuspense>
                <PrescriptionHistory />
              </PageSuspense>
            }
          />

          <Route
            path="settings"
            element={
              <PageSuspense>
                <Settings />
              </PageSuspense>
            }
          />
          <Route
            path="profile"
            element={
              <PageSuspense>
                <Profile />
              </PageSuspense>
            }
          />
        </Route>
      </Route>

      {/* Fallback */}
      <Route
        path="*"
        element={
          <PageSuspense>
            <NotFound />
          </PageSuspense>
        }
      />
    </Routes>
  );
}

export default AppRoutes;
