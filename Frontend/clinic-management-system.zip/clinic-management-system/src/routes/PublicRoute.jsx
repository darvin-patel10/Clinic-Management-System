import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@hooks/useAuth";
import Loader from "@components/common/Loader";
import { ROUTES } from "@utils/constants";

export function PublicRoute() {
  const { isAuthenticated, isInitializing } = useAuth();

  if (isInitializing) {
    return <Loader fullScreen label="Loading…" />;
  }

  if (isAuthenticated) {
    return <Navigate to={ROUTES.DASHBOARD} replace />;
  }

  return <Outlet />;
}

export default PublicRoute;
