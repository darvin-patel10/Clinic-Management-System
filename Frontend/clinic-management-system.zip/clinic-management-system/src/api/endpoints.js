// Single source of truth for API URL paths. Services import from here
// instead of hardcoding strings, so a backend route change only needs
// one edit.

export const ENDPOINTS = {
  AUTH: {
    LOGIN: "/auth/login",
    LOGOUT: "/auth/logout",
    REFRESH_TOKEN: "/auth/refresh-token",
    ME: "/auth/me",
  },
  DASHBOARD: {
    STATS: "/dashboard/stats",
    REVENUE: "/dashboard/revenue",
    RECENT_PATIENTS: "/dashboard/recent-patients",
    RECENT_PRESCRIPTIONS: "/dashboard/recent-prescriptions",
    LOW_STOCK_MEDICINES: "/dashboard/low-stock-medicines",
  },
  MEDICINES: {
    BASE: "/medicines",
    BY_ID: (id) => `/medicines/${id}`,
  },
  PATIENTS: {
    BASE: "/patients",
    BY_ID: (id) => `/patients/${id}`,
  },
  PRESCRIPTIONS: {
    BASE: "/prescriptions",
    BY_ID: (id) => `/prescriptions/${id}`,
    HISTORY: "/prescriptions/history",
  },
  PROFILE: {
    BASE: "/profile",
  },
  SETTINGS: {
    BASE: "/settings",
  },
};
