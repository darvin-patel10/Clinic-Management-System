# Clinic Management System — Frontend Foundation

Production-ready React + Vite frontend architecture for a doctors-only
Clinic Management System. This repo currently ships the **architecture
foundation only** — routing, layouts, providers, auth flow, and the
full reusable component library. Business features (Dashboard,
Medicines, Patients, Prescriptions) are scaffolded as routed
placeholder pages, ready to be built out.

## Start here

1. **[`Agent.md`](./Agent.md)** — binding engineering rules. Read this
   before writing any feature code.
2. **[`Design.md`](./Design.md)** — design tokens, visual system, and
   the rationale behind them.
3. **[`ProjectStructure.md`](./ProjectStructure.md)** — full folder
   tree and the responsibility of every directory.

## Quick start

```bash
npm install
cp .env.example .env      # set VITE_API_BASE_URL
npm run dev
```

## Stack

React · Vite · Tailwind CSS v4 · React Router v7 · Axios · TanStack
React Query · React Hook Form · Zod · Context API · Framer Motion ·
React Hot Toast · React Icons · Recharts
